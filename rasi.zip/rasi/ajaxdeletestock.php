<?php
include('ajaxconfig.php');
if(isset($_POST["stockid"])){
	$stockid  = $_POST["stockid"];
}
//  $deletestock = "DELETE FROM stocks WHERE stockid = '".$stockid."'";
//  $result = $mysqli->query($deletestock);
//  if($result){
//  	echo "<p style='text-align:center;color:green'>"."Stock Removed Succesfully!"."</p>";
//  }else{
//  	echo "<p style='text-align:center;color:red'>"."Error:"." ".$mysqli->error."</p>";
//  }

 
if($stockid>0){
	$update=$mysqli->query("UPDATE stocks SET status=1 WHERE stockid='".$stockid."' ");
	if($update == true){
		echo "<p style='text-align:center;color:green'>"."Stock Removed Succesfully!"."</p>";
	}else{
		echo "<p style='text-align:center;color:red'>"."Error:"." ".$mysqli->error."</p>";
	}
}

?>