<?php
include('ajaxconfig.php');

if (isset($_POST['stockid'])) {
    $stockid = $_POST['stockid'];
}
if (isset($_POST['stockname'])) {
    $stockname = $_POST['stockname'];
}

if($stockid>0){
	$update=$mysqli->query("UPDATE stocks SET stock='".$stockname."' WHERE stockid='".$stockid."' ");
	if($update == true){
		echo "<p style='text-align:center;color:green'>"."Stock Updated Succesfully!"."</p>";
	}else{
		echo "<p style='text-align:center;color:red'>"."Error:"." ".$mysqli->error."</p>";
	}
}else{
	$insert=$mysqli->query("INSERT INTO stocks(stock) VALUES('".strip_tags($stockname)."')");
	if($insert == true){
		echo "<p style='text-align:center;color:green'>"."Stock Added Succesfully!"."</p>";
	}else{
		echo "<p style='text-align:center;color:red'>"."Error:"." ".$mysqli->error."</p>";
	}
}
?>
                <div class="table-container stock-table" id="starttable">
				<div class="table-responsive">
				<table class="table custom-table m-0" >
				<thead>
				<tr>
					<th>Stock</th>
					<th>ACTION</th>
				</tr>
			    </thead>
			    <tbody>
					<?php
			
					$stockselect="SELECT * FROM stocks where status=0 ";
					$stockresult=$mysqli->query($stockselect);
					if($stockresult->num_rows>0){
					while($stocks=$stockresult->fetch_assoc()){
					?>
					<tr>
					<td><?php if(isset($stocks["stock"])){ echo $stocks["stock"]; }?></td>
					<td>
						<a id="editstock" value="<?php if(isset($stocks["stockid"])){ echo $stocks["stockid"];}?>"><span class="icon-border_color"></span></a> &nbsp

						 <a id="deletestock" value="<?php if(isset($stocks["stockid"])){ echo $stocks["stockid"]; }?>"><span class='icon-trash-2'></span>
					    </a>
			           </td>
				    </tr>
				    </tbody>
				    <?php }} ?>
				</table>
			</div>
		</div>