<?php
require_once('vendor/csvreader/php-excel-reader/excel_reader2.php');
require_once('vendor/csvreader/SpreadsheetReader.php');
include("ajaxconfig.php");

if(isset($_FILES["file"]["type"])){
$allowedFileType = ['application/vnd.ms-excel','text/xls','text/xlsx','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'];
if(in_array($_FILES["file"]["type"],$allowedFileType)){
        $targetPath = 'uploads/bulkimport/'.$_FILES['file']['name'];
        move_uploaded_file($_FILES['file']['tmp_name'], $targetPath);
        $Reader = new SpreadsheetReader($targetPath);
        $sheetCount = count($Reader->sheets());
        for($i=0;$i<$sheetCount;$i++)
        {
            $Reader->ChangeSheet($i);
            foreach ($Reader as $Row){
            $vendorcode = "";
            if(isset($Row[0])) {
            $vendorcode = mysqli_real_escape_string($con,$Row[0]);
            }
            $vendorname = "";
            if(isset($Row[1])) {
            $vendorname = mysqli_real_escape_string($con,$Row[1]);
            }
            $address1 = "";
            if(isset($Row[2])) {
            $address1 = mysqli_real_escape_string($con,$Row[2]);
            }
            $pincode = "";
            if(isset($Row[3])) {
            $pincode = mysqli_real_escape_string($con,$Row[3]);
            }
            $stocktype = "";
            if(isset($Row[4])) {
            $stocktype = mysqli_real_escape_string($con,$Row[4]);
            }
            $deliverytime = "";
            if(isset($Row[5])) {
            $deliverytime = mysqli_real_escape_string($con,$Row[5]);
            }
            $reorderlevel = "";
            if(isset($Row[6])) {
            $reorderlevel = mysqli_real_escape_string($con,$Row[6]);
            }
            $contactperson = "";
            if(isset($Row[7])) {
            $contactperson = mysqli_real_escape_string($con,$Row[7]);
            }
            $contact = "";
            if(isset($Row[8])) {
            $contact = mysqli_real_escape_string($con,$Row[8]);
            }
            $mailid = "";
            if(isset($Row[9])) {
            $mailid = mysqli_real_escape_string($con,$Row[9]);
            }

        if($i==0)
        { 
        $query = "INSERT INTO vendor(vendorcode, vendorname, address1, pincode, stocktype, deliverytime, reorderlevel, contactperson, contact, mailid) VALUES (
       '".strip_tags($vendorcode)."',
       '".strip_tags($vendorname)."',
       '".strip_tags($address1)."',
       '".strip_tags($pincode)."',
       '".strip_tags($stocktype)."',
       '".strip_tags($deliverytime)."',
       '".strip_tags($reorderlevel)."',
       '".strip_tags($contactperson)."',
       '".strip_tags($contact)."',
       '".strip_tags($mailid)."') ";

       $result = $con->query($query);

    } } }  

    if(!empty($result)) {
    echo "Excel Data Imported into the Database !";
    }
    else{
    echo "Problem in Importing Excel Data".$con->error;
    }
}
}else{
    echo "Kindly Select The Excel";
}

?>