-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 04, 2021 at 04:41 AM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rasi`
--

-- --------------------------------------------------------

--
-- Table structure for table `branch`
--

CREATE TABLE `branch` (
  `branchid` int(11) NOT NULL,
  `branchname` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `address1` varchar(255) NOT NULL,
  `address2` varchar(255) NOT NULL,
  `pincode` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `phonenumber` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `faxnumber` varchar(255) NOT NULL,
  `tanno` varchar(255) NOT NULL,
  `gst` varchar(255) NOT NULL,
  `pfno` varchar(255) NOT NULL,
  `esicno` varchar(255) NOT NULL,
  `loginshortername` varchar(255) NOT NULL,
  `status` varchar(10) NOT NULL,
  `createddate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `branch`
--

INSERT INTO `branch` (`branchid`, `branchname`, `address`, `address1`, `address2`, `pincode`, `state`, `country`, `phonenumber`, `email`, `faxnumber`, `tanno`, `gst`, `pfno`, `esicno`, `loginshortername`, `status`, `createddate`) VALUES
(2, 'branch21', 'address1', 'address11', 'address21', '123451', 'tamilnadu1', 'india1', '1234567891', 'karthiscores1@gmail.com', '1234561', '1231', '2341', '4561', '6781', 'login ok1', '0', '2021-05-28 02:18:02');

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

CREATE TABLE `company` (
  `companyid` int(11) NOT NULL,
  `companyname` varchar(255) NOT NULL,
  `cinno` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `address1` varchar(255) NOT NULL,
  `address2` varchar(255) NOT NULL,
  `pincode` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `phonenumber` varchar(255) NOT NULL,
  `faxnumber` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `website` varchar(255) NOT NULL,
  `panno` varchar(255) NOT NULL,
  `itwardcircleno` varchar(255) NOT NULL,
  `tanno` varchar(255) NOT NULL,
  `gst` varchar(255) NOT NULL,
  `pfno` varchar(255) NOT NULL,
  `esicno` varchar(255) NOT NULL,
  `loginshortername` varchar(255) NOT NULL,
  `booksstartfrom` varchar(255) NOT NULL,
  `companyimagepath` varchar(255) NOT NULL,
  `status` varchar(10) NOT NULL,
  `createddate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `company`
--

INSERT INTO `company` (`companyid`, `companyname`, `cinno`, `address`, `address1`, `address2`, `pincode`, `state`, `country`, `phonenumber`, `faxnumber`, `email`, `website`, `panno`, `itwardcircleno`, `tanno`, `gst`, `pfno`, `esicno`, `loginshortername`, `booksstartfrom`, `companyimagepath`, `status`, `createddate`) VALUES
(1, 'comp1', '12341', 'address1', 'address11', 'address21', '123451', 'state1', 'country1', '1234567891', '1234567891', 'email1@gmail.com', 'www.i1.com', '1234566871', '12341231', '12341231', '22342421', '22345561', '22345571', 'shorter1', '13 May, 2021', '', '0', '2021-05-28 16:38:49'),
(2, 'weerewr', 'wetew', 'qwewq', 'qwe', 'qwewq', '234214', 'dsqadqd', 'wqdwqde', '2323232322', '2323232323', 'karthiprice@gmail.com', 'eqqweqwe', 'cypdk2666r', '2233', '3344', '4455', '123', '456', 'login', '20 May, 2021', '', '0', '2021-05-28 19:39:18'),
(3, 'comp1', '12341', 'address1', 'address11', 'address21', '123456', 'state1', 'country1', '3253253253', '1234567891', 'karthiprice@gmail.com', 'reyreyer.com', 'cypdk2666r', '12341231', '12341231', '22342421', '22345561', '22345571', 'login', '13 May, 2021', 'c404bacf-52c1-4ba3-8a80-2e382b2bb4fe.jpg', '0', '2021-05-28 19:45:44');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `customid` int(11) NOT NULL,
  `customerid` varchar(100) NOT NULL,
  `customername` varchar(100) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `dateofbirth` varchar(30) NOT NULL,
  `customerimage` varchar(100) NOT NULL,
  `age` varchar(20) NOT NULL,
  `mobilenumber` varchar(30) NOT NULL,
  `whatsappnumber` varchar(30) NOT NULL,
  `anniverserydate` varchar(30) NOT NULL,
  `emailid` varchar(100) NOT NULL,
  `needmembership` varchar(20) NOT NULL,
  `gstno` varchar(100) NOT NULL,
  `contactpersion` varchar(100) NOT NULL,
  `address1` varchar(100) NOT NULL,
  `address2` varchar(100) NOT NULL,
  `pincode` varchar(15) NOT NULL,
  `state` varchar(100) NOT NULL,
  `typeofcustomer` varchar(30) NOT NULL,
  `noofvisit` varchar(20) NOT NULL,
  `frequencyofvisit` varchar(50) NOT NULL,
  `subgroup` varchar(100) NOT NULL,
  `groups` varchar(100) NOT NULL,
  `ledgername` varchar(100) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`customid`, `customerid`, `customername`, `gender`, `dateofbirth`, `customerimage`, `age`, `mobilenumber`, `whatsappnumber`, `anniverserydate`, `emailid`, `needmembership`, `gstno`, `contactpersion`, `address1`, `address2`, `pincode`, `state`, `typeofcustomer`, `noofvisit`, `frequencyofvisit`, `subgroup`, `groups`, `ledgername`, `status`) VALUES
(4, 'DWE3432', 'ramki', 'Male', '03/01/1997', 'sbscds.jpg', '23', '8762740344', '3749326874', '23/12/1878', 'djasdf@g.com', 'Yes', 'SDFSAFFR12SDS', 'judfr', '12/23,efyguyf,aufui', 'fueufe', '453443', 'TamilNadu', 'New', '23', '234', 'vdfvgdh', 'shgufsdh', 'ramki', 0),
(5, 'AA23232', 'krish', 'Female', '2021-06-11', 'feather-technology-logo.png', '23', '4523523243', '8270411648', '2021-06-24', 'hsgwu@g.com', 'Yes', 'HSGDYSU32BQ', 'hddhssioas', 'no.4,hfwg', 'nachalur,', '639110', 'Jharkhand', 'Regular', '23', '423', '1011', '3dwfasdad', 'dvasdvdf', 1);

-- --------------------------------------------------------

--
-- Table structure for table `designation`
--

CREATE TABLE `designation` (
  `designationid` int(10) NOT NULL,
  `designation` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `designation`
--

INSERT INTO `designation` (`designationid`, `designation`) VALUES
(2, 'Teacher Updated'),
(3, 'Doctor Update'),
(4, 'Engineer'),
(6, 'New Demo');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `employeeid` int(11) NOT NULL,
  `employeecode` varchar(100) DEFAULT NULL,
  `employeename` varchar(100) DEFAULT NULL,
  `dateofbirth` varchar(50) DEFAULT NULL,
  `gender` varchar(30) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `designation` varchar(40) DEFAULT NULL,
  `mobilenumber` varchar(50) DEFAULT NULL,
  `dateofjoining` varchar(50) DEFAULT NULL,
  `contact` varchar(50) DEFAULT NULL,
  `employeeimage` varchar(50) DEFAULT NULL,
  `expertise` varchar(50) DEFAULT NULL,
  `starrating` varchar(20) DEFAULT NULL,
  `basic` int(50) DEFAULT NULL,
  `hra` int(50) DEFAULT NULL,
  `conveyance` int(50) DEFAULT NULL,
  `allowance` int(50) DEFAULT NULL,
  `incentivepercent` int(50) DEFAULT NULL,
  `grosspay` int(50) DEFAULT NULL,
  `tds` int(50) DEFAULT NULL,
  `pf` int(50) DEFAULT NULL,
  `esi` int(50) DEFAULT NULL,
  `loans` int(50) DEFAULT NULL,
  `salaryadvance` int(50) DEFAULT NULL,
  `totaldeduction` int(50) DEFAULT NULL,
  `anyotherdeduction` int(50) DEFAULT NULL,
  `institutetype1` varchar(100) DEFAULT NULL,
  `name1` varchar(100) DEFAULT NULL,
  `positionheld1` varchar(50) DEFAULT NULL,
  `place1` varchar(50) DEFAULT NULL,
  `fromperiod1` varchar(50) DEFAULT NULL,
  `toperiod1` varchar(50) DEFAULT NULL,
  `date1` varchar(30) DEFAULT NULL,
  `institutetype2` varchar(100) DEFAULT NULL,
  `name2` varchar(50) DEFAULT NULL,
  `positionheld2` varchar(50) DEFAULT NULL,
  `place2` varchar(50) DEFAULT NULL,
  `fromperiod2` varchar(50) DEFAULT NULL,
  `toperiod2` varchar(50) DEFAULT NULL,
  `date2` varchar(50) DEFAULT NULL,
  `institutetype3` varchar(100) DEFAULT NULL,
  `name3` varchar(50) DEFAULT NULL,
  `positionheld3` varchar(50) DEFAULT NULL,
  `place3` varchar(50) DEFAULT NULL,
  `fromperiod3` varchar(50) DEFAULT NULL,
  `toperiod3` varchar(50) DEFAULT NULL,
  `date3` varchar(50) DEFAULT NULL,
  `institutetype4` varchar(100) DEFAULT NULL,
  `name4` varchar(50) DEFAULT NULL,
  `positionheld4` varchar(50) DEFAULT NULL,
  `place4` varchar(50) DEFAULT NULL,
  `fromperiod4` varchar(50) DEFAULT NULL,
  `toperiod4` varchar(50) DEFAULT NULL,
  `date4` varchar(50) DEFAULT NULL,
  `institutetype5` varchar(100) DEFAULT NULL,
  `name5` varchar(50) DEFAULT NULL,
  `positionheld5` varchar(50) DEFAULT NULL,
  `place5` varchar(50) DEFAULT NULL,
  `fromperiod5` varchar(50) DEFAULT NULL,
  `toperiod5` varchar(50) DEFAULT NULL,
  `date5` varchar(50) DEFAULT NULL,
  `title1` varchar(100) DEFAULT NULL,
  `certificate1` varchar(100) DEFAULT NULL,
  `title2` varchar(100) DEFAULT NULL,
  `certificate2` varchar(100) DEFAULT NULL,
  `title3` varchar(100) DEFAULT NULL,
  `certificate3` varchar(100) DEFAULT NULL,
  `title4` varchar(100) DEFAULT NULL,
  `certificate4` varchar(100) DEFAULT NULL,
  `title5` varchar(100) DEFAULT NULL,
  `certificate5` varchar(100) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`employeeid`, `employeecode`, `employeename`, `dateofbirth`, `gender`, `email`, `designation`, `mobilenumber`, `dateofjoining`, `contact`, `employeeimage`, `expertise`, `starrating`, `basic`, `hra`, `conveyance`, `allowance`, `incentivepercent`, `grosspay`, `tds`, `pf`, `esi`, `loans`, `salaryadvance`, `totaldeduction`, `anyotherdeduction`, `institutetype1`, `name1`, `positionheld1`, `place1`, `fromperiod1`, `toperiod1`, `date1`, `institutetype2`, `name2`, `positionheld2`, `place2`, `fromperiod2`, `toperiod2`, `date2`, `institutetype3`, `name3`, `positionheld3`, `place3`, `fromperiod3`, `toperiod3`, `date3`, `institutetype4`, `name4`, `positionheld4`, `place4`, `fromperiod4`, `toperiod4`, `date4`, `institutetype5`, `name5`, `positionheld5`, `place5`, `fromperiod5`, `toperiod5`, `date5`, `title1`, `certificate1`, `title2`, `certificate2`, `title3`, `certificate3`, `title4`, `certificate4`, `title5`, `certificate5`, `status`) VALUES
(1, '1001', 'prithiviraj', '2021-05-06', 'Male', 'prithivirajk2503@gmail.com', 'Manager', '06381268718', '2021-05-07', '06381268718', 'in4.jpg', '76', '4', 2, 2, 2, 2, 23, 31, 23, 23, 23, 66, 66, 267, 66, 'Technical', 'Prithiviraj', 'K', 'Melathaniyam', '87568', '875', '85', 'Select Institute Type', '', '', '', '', '', '', 'Select Institute Type', '', '', '', '', '', '', 'Select Institute Type', '', '', '', '', '', '', 'Select Institute Type', '', '', '', '', '', '', '', 'PRITHIVIRAJ.pdf', '', '', '', '', '', '', '', '', '0');

-- --------------------------------------------------------

--
-- Table structure for table `item`
--

CREATE TABLE `item` (
  `itemid` int(10) NOT NULL,
  `partnumber` varchar(200) DEFAULT NULL,
  `stocktype` varchar(200) DEFAULT NULL,
  `itemname` varchar(200) DEFAULT NULL,
  `unitofmeasure` varchar(200) DEFAULT NULL,
  `hsncode` varchar(200) DEFAULT NULL,
  `gstrate` varchar(200) DEFAULT NULL,
  `barcode` varchar(200) DEFAULT NULL,
  `vendor` varchar(200) DEFAULT NULL,
  `type` varchar(200) DEFAULT NULL,
  `noofgmpcs` varchar(200) DEFAULT NULL,
  `reorderlevel` varchar(200) DEFAULT NULL,
  `lowerlevelqty` varchar(200) DEFAULT NULL,
  `isincentive` varchar(200) DEFAULT NULL,
  `isreuse` varchar(200) DEFAULT NULL,
  `tablevendorselect` varchar(200) DEFAULT NULL,
  `tableopeningstock` varchar(200) DEFAULT NULL,
  `tableopeningpcs` varchar(200) DEFAULT NULL,
  `tablecostperunit` varchar(200) DEFAULT NULL,
  `tablecostprice` varchar(200) DEFAULT NULL,
  `tablesellingpriceperpc` varchar(200) DEFAULT NULL,
  `tabletotalsellingprice` varchar(200) DEFAULT NULL,
  `status` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `item`
--

INSERT INTO `item` (`itemid`, `partnumber`, `stocktype`, `itemname`, `unitofmeasure`, `hsncode`, `gstrate`, `barcode`, `vendor`, `type`, `noofgmpcs`, `reorderlevel`, `lowerlevelqty`, `isincentive`, `isreuse`, `tablevendorselect`, `tableopeningstock`, `tableopeningpcs`, `tablecostperunit`, `tablecostprice`, `tablesellingpriceperpc`, `tabletotalsellingprice`, `status`) VALUES
(1, '1001', 'Sale', 'Chair', 'Gram', '72723', '12', '23423', 'VEN0001', 'plastic', '3', '13', '12', 'yes', 'no', 'VEN0001,VEN0002,', '1,1,', '2,1,', '2,1,', '2,1,', '1,1,', '1,1,', '0'),
(2, '65', 'Stock', 'qweqwe', 'Count', '765', '766', '776', 'VEN0002', '76567', '7656', '567', '76567', 'yes', 'yes', '', '', '', '', '', '', '', '0'),
(3, '1003', 'Towel', 'Towel', 'Count updated', '8723', '7235', '87235', 'VEN0001', 'cotton', '23', '234', '34', 'yes', 'yes', '', '', '', '', '', '', '', '0'),
(4, '87328', 'Sale', '85238', 'Gram', '76', '632', '875132', 'VEN0007', '7613', '7851283', '87', '632', 'yes', 'yes', 'VEN0007,VEN0002', '761,234', '1623,234', '83,234', '63163,54756', '623,234', '474103,54756', '0'),
(5, '873', 'Stock', 'shoes', 'Gram', '35', '87', 'kahsiu', 'VEN0002', '286387', '8723', '87235', '87235', 'yes', 'yes', '', '', '', '', '', '', '', '0'),
(6, '9008', 'Tools', 'Cutter', 'pieces', '823687', '872', '232', 'VEN0003', 'iron pices', '18', '15', '16', 'yes', 'no', 'VEN0001,VEN0005,VEN0010,VEN0011,VEN0002', '2,234,4,3,12', '56,3,4,4,123', '54,3,4,42,23', '108,702,16,126,276', '324,3,4,123,23', '648,702,16,369,276', '1');

-- --------------------------------------------------------

--
-- Table structure for table `stocks`
--

CREATE TABLE `stocks` (
  `stockid` int(10) NOT NULL,
  `stock` varchar(50) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `stocks`
--

INSERT INTO `stocks` (`stockid`, `stock`, `status`) VALUES
(1, 'Dress1', 0),
(2, 'Nuts', 0),
(3, 'ok', 1);

-- --------------------------------------------------------

--
-- Table structure for table `taxmaster`
--

CREATE TABLE `taxmaster` (
  `taxid` int(11) NOT NULL,
  `financialyear` varchar(50) NOT NULL,
  `classification` varchar(50) NOT NULL,
  `description` varchar(100) NOT NULL,
  `tax` varchar(100) NOT NULL,
  `cess` varchar(50) NOT NULL,
  `addl` varchar(100) NOT NULL,
  `total` varchar(100) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `taxmaster`
--

INSERT INTO `taxmaster` (`taxid`, `financialyear`, `classification`, `description`, `tax`, `cess`, `addl`, `total`, `status`) VALUES
(1, '2001-2002', 'jhsdjshbds', 'sjdhfsud', '5', '50', '500', '555', '0'),
(2, '2005-2006', 'Custom Duty', 'judfua', '20000', '1000', '3726', '24726', '0'),
(3, '2009-2010', 'Custom Duty', 'ramakrishnan tax report', '1214', '2134213', '23412', '2158838', '0');

-- --------------------------------------------------------

--
-- Table structure for table `units`
--

CREATE TABLE `units` (
  `unitid` int(15) NOT NULL,
  `unit` varchar(30) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `units`
--

INSERT INTO `units` (`unitid`, `unit`, `status`) VALUES
(3, 'Ton1', 0),
(4, 'weight', 0),
(12, 'Update', 0),
(14, 'Count updated *', 0),
(15, 'Gram', 0),
(17, 'Ok Insert', 0),
(18, 'pieces', 0);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `user_password` varchar(255) NOT NULL,
  `role` varchar(50) NOT NULL,
  `trustactive` varchar(50) NOT NULL,
  `schoolcreationactive` varchar(50) NOT NULL,
  `manageuseractive` varchar(50) NOT NULL,
  `feemasteractive` varchar(50) NOT NULL,
  `subjectmasteractive` varchar(50) NOT NULL,
  `subjectgroupmasteractive` varchar(50) NOT NULL,
  `staffmasteractive` varchar(50) NOT NULL,
  `holidayinfoactive` varchar(50) NOT NULL,
  `createstudentactive` varchar(50) NOT NULL,
  `studentrollback` varchar(50) NOT NULL,
  `bulkimport` varchar(50) NOT NULL,
  `feescollectionactive` varchar(50) NOT NULL,
  `historyactive` varchar(50) NOT NULL,
  `birthdaywishesactive` varchar(50) NOT NULL,
  `generalwishesactive` varchar(50) NOT NULL,
  `paymentreminderactive` varchar(50) NOT NULL,
  `studentreportactive` varchar(50) NOT NULL,
  `castereportactive` varchar(50) NOT NULL,
  `pendingfeereportactive` varchar(50) NOT NULL,
  `collectionreportactive` varchar(50) NOT NULL,
  `status` varchar(255) NOT NULL,
  `Createddate` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `fullname`, `user_name`, `user_password`, `role`, `trustactive`, `schoolcreationactive`, `manageuseractive`, `feemasteractive`, `subjectmasteractive`, `subjectgroupmasteractive`, `staffmasteractive`, `holidayinfoactive`, `createstudentactive`, `studentrollback`, `bulkimport`, `feescollectionactive`, `historyactive`, `birthdaywishesactive`, `generalwishesactive`, `paymentreminderactive`, `studentreportactive`, `castereportactive`, `pendingfeereportactive`, `collectionreportactive`, `status`, `Createddate`) VALUES
(1, 'admin', 'support@feathertechnology.in', 'feather123', '1', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '2021-04-17 17:08:00');

-- --------------------------------------------------------

--
-- Table structure for table `user_logs`
--

CREATE TABLE `user_logs` (
  `loginid` int(11) NOT NULL,
  `ipaddress` varchar(255) NOT NULL,
  `login_date` varchar(255) NOT NULL,
  `fk_user_id` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_logs`
--

INSERT INTO `user_logs` (`loginid`, `ipaddress`, `login_date`, `fk_user_id`) VALUES
(1, '::1', '2021-04-17 05:14:16', '1'),
(2, '::1', '2021-04-17 05:16:15', '1'),
(3, '::1', '2021-04-17 05:17:36', '1'),
(4, '::1', '2021-04-19 09:50:40', '1'),
(5, '::1', '2021-04-23 10:45:10', '1'),
(6, '::1', '2021-04-24 06:52:22', '1'),
(7, '::1', '2021-04-24 10:36:30', '1'),
(8, '::1', '2021-04-24 10:37:55', '1'),
(9, '::1', '2021-04-24 10:39:46', '1'),
(10, '::1', '2021-04-24 11:56:41', '1'),
(11, '::1', '2021-04-25 12:28:33', '1'),
(12, '::1', '2021-04-26 10:23:53', '1'),
(13, '::1', '2021-04-26 10:42:25', '1'),
(14, '::1', '2021-04-27 01:32:36', '1'),
(15, '::1', '2021-04-27 08:12:46', '1'),
(16, '::1', '2021-04-29 10:34:22', '1'),
(17, '::1', '2021-04-29 11:20:33', '1'),
(18, '::1', '2021-04-30 10:33:16', '1'),
(19, '::1', '2021-04-30 10:34:57', '1'),
(20, '::1', '2021-05-01 12:21:25', '1'),
(21, '::1', '2021-05-01 04:54:12', '1'),
(22, '::1', '2021-05-04 10:27:10', '1'),
(23, '::1', '2021-05-05 07:25:33', '1'),
(24, '::1', '2021-05-06 12:03:20', '1'),
(25, '::1', '2021-05-06 11:00:45', '1'),
(26, '::1', '2021-05-07 04:28:21', '1'),
(27, '::1', '2021-05-07 05:24:13', '1'),
(28, '::1', '2021-05-07 11:56:56', '1'),
(29, '::1', '2021-05-09 03:58:57', '1'),
(30, '::1', '2021-05-13 04:22:59', '1'),
(31, '::1', '2021-05-13 11:57:33', '1'),
(32, '::1', '2021-05-14 04:29:22', '1'),
(33, '::1', '2021-05-14 08:09:56', '1'),
(34, '::1', '2021-05-18 06:10:48', '1'),
(35, '::1', '2021-05-19 06:18:37', '1'),
(36, '::1', '2021-05-20 05:55:25', '1'),
(37, '::1', '2021-05-20 06:29:46', '2'),
(38, '::1', '2021-05-20 06:30:46', '2'),
(39, '::1', '2021-05-20 06:31:03', '2'),
(40, '::1', '2021-05-20 06:31:17', '2'),
(41, '::1', '2021-05-29 01:50:15', '1'),
(42, '::1', '2021-05-29 01:50:27', '1'),
(43, '::1', '2021-05-29 05:07:36', '1'),
(44, '::1', '2021-05-29 05:12:11', '1'),
(45, '::1', '2021-05-31 06:30:13', '1'),
(46, '::1', '2021-06-03 01:02:48', '1'),
(47, '::1', '2021-06-03 08:02:54', '1'),
(48, '::1', '2021-06-04 06:45:22', '1');

-- --------------------------------------------------------

--
-- Table structure for table `vendor`
--

CREATE TABLE `vendor` (
  `vendorid` int(10) NOT NULL,
  `vendorcode` varchar(30) NOT NULL,
  `vendorname` varchar(50) NOT NULL,
  `address1` varchar(50) NOT NULL,
  `address2` varchar(30) NOT NULL,
  `pincode` varchar(10) NOT NULL,
  `contactperson` varchar(30) NOT NULL,
  `contact` varchar(15) NOT NULL,
  `mailid` varchar(50) NOT NULL,
  `gstnumber` varchar(50) NOT NULL,
  `pannumber` varchar(50) NOT NULL,
  `stocktype` varchar(50) NOT NULL,
  `deliverytime` varchar(50) NOT NULL,
  `reorderlevel` varchar(50) NOT NULL,
  `minimumstock` varchar(50) NOT NULL,
  `maximumstock` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `vendor`
--

INSERT INTO `vendor` (`vendorid`, `vendorcode`, `vendorname`, `address1`, `address2`, `pincode`, `contactperson`, `contact`, `mailid`, `gstnumber`, `pannumber`, `stocktype`, `deliverytime`, `reorderlevel`, `minimumstock`, `maximumstock`, `status`) VALUES
(1, 'VEN0001', 'prithiviraj', '126 kamarajaburam street', 'Melathaniyam', '622002', 'Prithiviraj K', '6381268718', 'prithivirajk2503@gmail.com', '01ABCDE2345F6Z7', 'ABCDE1234F', 'Dress', '10', '25', '10', '100', '1'),
(3, 'VEN0002', 'Rajesh Kumar', '127 kamarajaburam street', 'Melathaniyam', '622002', 'Prithiviraj K', '9876543211', 'rajesh@gmail.com', '01AEFDE2345F6Z7', 'AWRTE8765K', 'Nuts', '10', '15', '10', '20', '0'),
(4, 'VEN0003', 'Ajithsiva', '103, Pallavaram', 'Chenna', '600018', 'Prithiviraj K', '8128763266', 'ajithsiva@gmail.com', '01AEFDE2345F6Z7', 'AWRTE8765K', 'Dress', '15', '12', '10', '20', '0'),
(7, 'VEN0004', 'VVS', 'vellore', '', '632518', 'vvs', '8754111586', 'laxman17@gmal.com', '', '', 'Stock', '02-25-19', '22', '', '', '0'),
(8, 'VEN0003', 'VVS updated', 'vellore updated', '', '632518', 'vvs', '8754111586', 'laxman17@gmal.com', '', '', 'Stock', '02-25-19', '22', '', '', '0');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `branch`
--
ALTER TABLE `branch`
  ADD PRIMARY KEY (`branchid`);

--
-- Indexes for table `company`
--
ALTER TABLE `company`
  ADD PRIMARY KEY (`companyid`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`customid`);

--
-- Indexes for table `designation`
--
ALTER TABLE `designation`
  ADD PRIMARY KEY (`designationid`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`employeeid`);

--
-- Indexes for table `item`
--
ALTER TABLE `item`
  ADD PRIMARY KEY (`itemid`);

--
-- Indexes for table `stocks`
--
ALTER TABLE `stocks`
  ADD PRIMARY KEY (`stockid`);

--
-- Indexes for table `taxmaster`
--
ALTER TABLE `taxmaster`
  ADD PRIMARY KEY (`taxid`);

--
-- Indexes for table `units`
--
ALTER TABLE `units`
  ADD PRIMARY KEY (`unitid`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `user_logs`
--
ALTER TABLE `user_logs`
  ADD PRIMARY KEY (`loginid`);

--
-- Indexes for table `vendor`
--
ALTER TABLE `vendor`
  ADD PRIMARY KEY (`vendorid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `branch`
--
ALTER TABLE `branch`
  MODIFY `branchid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `company`
--
ALTER TABLE `company`
  MODIFY `companyid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `customid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `designation`
--
ALTER TABLE `designation`
  MODIFY `designationid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `employeeid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `item`
--
ALTER TABLE `item`
  MODIFY `itemid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `stocks`
--
ALTER TABLE `stocks`
  MODIFY `stockid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `taxmaster`
--
ALTER TABLE `taxmaster`
  MODIFY `taxid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `units`
--
ALTER TABLE `units`
  MODIFY `unitid` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `user_logs`
--
ALTER TABLE `user_logs`
  MODIFY `loginid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT for table `vendor`
--
ALTER TABLE `vendor`
  MODIFY `vendorid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
