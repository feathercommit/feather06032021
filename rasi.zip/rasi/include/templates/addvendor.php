<?php

$id=0;
	
if(isset($_POST['submitvendorbtn']) && $_POST['submitvendorbtn'] != '')
{  
if(isset($_POST['id']) && $_POST['id'] >0 && is_numeric($_POST['id'])){		
	$id = $_POST['id']; 	
    $vendorupdatedetails = $userObj->updatevendor($mysqli,$id);  
    ?>
   <script>location.href='<?php echo $HOSTPATH;  ?>editvendor&msc=2';</script>
    <?php }
    else{   
		$vendoradddetails = $userObj->addvendor($mysqli);   
        ?>
    <script>location.href='<?php echo $HOSTPATH;  ?>editvendor&msc=1';</script> 
        <?php
    }
 }

$del=0;
if(isset($_GET['del']))
{
$del=$_GET['del'];
}
if($del>0)
{
	$vendordeletedetails = $userObj->deletevendor($mysqli,$del); 
	?>
	<script>location.href='<?php echo $HOSTPATH;  ?>editvendor&msc=3';</script>
<?php	
}

if(isset($_GET['upd']))
{
$idupd=$_GET['upd'];
}
$status = 0;
if($idupd>0)
{
	$vendordetails = $userObj->getvendor($mysqli,$idupd); 
	
	if (sizeof($vendordetails)>0) {
        for($ivendor=0;$ivendor<sizeof($vendordetails);$ivendor++) {			
			$vendorid         = $vendordetails['vendorid'];
			$vendorcode       = $vendordetails['vendorcode'];
			$vendorname       = $vendordetails['vendorname'];
			$address1         = $vendordetails['address1'];
			$address2         = $vendordetails['address2'];

			$pincode          = $vendordetails['pincode'];
			$contactperson    = $vendordetails['contactperson'];
			$contact          = $vendordetails['contact'];
			$mailid           = $vendordetails['mailid'];
			$gstnumber        = $vendordetails['gstnumber'];
			$pannumber        = $vendordetails['pannumber'];
			$stocktype        = $vendordetails['stocktype'];
			$deliverytime     = $vendordetails['deliverytime'];

			$reorderlevel     = $vendordetails['reorderlevel'];
			$minimumstock     = $vendordetails['minimumstock'];
			$maximumstock     = $vendordetails['maximumstock'];
			$status           = $vendordetails['status'];

		}
	}
}
?>


<!-- Page header start -->
				<div class="page-header">
					<ol class="breadcrumb">
						<li class="breadcrumb-item">Local Vendor Creation</li>
					</ol>

                <a href="editvendor">
					<button type="button" class="btn btn-primary"><span class="icon-border_color"></span>&nbsp Edit Vendor</button>
					</a>
				</div>
				<!-- Page header end -->

<div class="main-container">
					<!-- Row start -->
					<form action="" method="post" name="vendorcreation" id="vendorcreation">
					<div class="row gutters">
            <!-- General Info -->
					<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
						<div class="card">
								<div class="card-header">General Info</div>
								<div class="card-body row">
									<input type="hidden" name="id" id="id" class="form-control" value="<?php if(isset($vendorid)) echo $vendorid ; ?>">

									<div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-12">
											<div class="form-group">
												<label class="label">Vendor Code</label>
													<input type="text" tabindex="1" name="vendorcode" id="vendorcode" class="form-control" placeholder="Enter Vendor Code" value="<?php if(isset($vendorcode )) echo $vendorcode ; ?>">
											</div>
										</div>

										<div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-12">
											<div class="form-group">
												<label class="label">Vendor Name<span class="text-danger">*</span></label>
													<input type="text" tabindex="2" name="vendorname" id="vendorname" class="form-control" placeholder="Enter Vendor Name" value="<?php if(isset($vendorname )) echo $vendorname ; ?>">
													<span class="text-danger" id="vendornamecheck">Enter Vendor Name</span>
											</div>
										</div>

										<div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-12">
											<div class="form-group">
												<label class="label">Address 1</label>
													<input type="text" tabindex="3" name="address1" id="address1" class="form-control" placeholder="Enter Address 1" value="<?php if(isset($address1 )) echo $address1 ; ?>">
											</div>
										</div>

										<div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-12">
											<div class="form-group">
												<label class="label">Address 2</label>
													<input type="text" tabindex="4" name="address2" id="address2" class="form-control" placeholder="Enter Address 2" value="<?php if(isset($address2 )) echo $address2 ; ?>">
											</div>
										</div>


										<div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-12">
											<div class="form-group">
												<label class="label">Pin Code</label>
													<input  type="number" tabindex="5" name="pincode" id="pincode" class="form-control" placeholder="Enter Pincode" value="<?php if(isset($pincode )) echo $pincode ; ?>" pattern="/^-?\d+\.?\d*$/" onKeyPress="if(this.value.length==6) return false;">
											</div>
										</div>

										<div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-12">
											<div class="form-group">
												<label class="label">Contact Person</label>
													<input type="text" tabindex="5" name="contactperson" id="contactperson" class="form-control" placeholder="Enter Enter Contact Person" value="<?php if(isset($contactperson )) echo $contactperson ; ?>">
											</div>
										</div>

										<div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-12">
											<div class="form-group">
												<label class="label">Contact No</label>
													<input  type="number" tabindex="5" name="contact" id="contact" class="form-control" placeholder="Enter Contact No" value="<?php if(isset($contact )) echo $contact ; ?>" pattern="/^-?\d+\.?\d*$/" onKeyPress="if(this.value.length==10) return false;">
											</div>
										</div>

										<div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-12">
											<div class="form-group">
												<label class="label">Mail Id</label>
													<input type="text" tabindex="5" name="mailid" id="mailid" class="form-control" placeholder="Enter Mail Id" value="<?php if(isset($mailid )) echo $mailid ; ?>">
													<span class="text-danger" id="mailidcheck">Enter Valid Mail Id</span>
											</div>
										</div>

										<div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-12">
											<div class="form-group">
												<label class="label">GST No</label>
													<input  type="text" tabindex="5" name="gstnumber" id="gstnumber" class="form-control" placeholder="Enter GST No" value="<?php if(isset($gstnumber )) echo $gstnumber ; ?>"  onKeyPress="if(this.value.length==16) return false;">
													<span class="text-danger" id="gstnumbercheck">Enter Valid GST Number</span>
											</div>
										</div>

										<div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-12">
											<div class="form-group">
												<label class="label">PAN No</label>
													<input  type="text" tabindex="5" name="pannumber" id="pannumber" class="form-control" placeholder="Enter PAN No" value="<?php if(isset($pannumber )) echo $pannumber ; ?>" onKeyPress="if(this.value.length==11) return false;">
													<span class="text-danger" id="pannumbercheck">Enter Valid PAN Number</span>
											</div>
										</div>

									</div>
								</div>
							</div>

<div>
<div id="AddStockModal" class="modal">
  <div class="modal-content">
    <span class="close" style="width:4%;">&times;</span>
  <iframe src="addstock.php" height="500px"></iframe>
  </div>
</div>
</div>

<div>
<div id="VendorBulkUploadModal" class="modal">
  <div class="modal-content">
    <span class="bulkclose" style="width:4%;">&times;</span>
  <iframe src="vendorbulkupload.php" height="200px"></iframe>
  </div>
</div>
</div>

							<!-- Stock Info -->

						<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
						<div class="card">
								<div class="card-header">Stock Info</div>
								<div class="card-body row">

									<div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-12">
											<div class="form-group">
												<label class="label">Select Stock Type<span class="text-danger">*</span></label>
												 <select tabindex="4" name="stocktype" id="stocktype" class="form-control comp-field  chosen-select">
														<option value="">Select Stock Type</option>
														<?php
														$stockselect="SELECT stock FROM stocks WHERE 1 and status=0";
														$stockresult=$mysqli->query($stockselect);
														$stocklist=array();
														if($stockresult->num_rows>0){
														while($stocks=$stockresult->fetch_assoc()){
														 $stocklist[]=$stocks["stock"];
													}
													}
													for($i=0;$i<=sizeof($stocklist)-1;$i++){
														?>
													<option <?php if(isset($stocktype)) { if($stocktype == $stocklist[$i] ) echo 'selected'; } ?> value="<?php if(isset($stocklist[$i])){ echo $stocklist[$i];} ?>"><?php if(isset($stocklist[$i])){ echo $stocklist[$i];} ?></option>
												<?php } ?>
													</select> 
													<span class="text-danger" id="stocktypecheck">Select  Stock Type</span>
												</div>
											</div>
											<div class="col-xl-1 col-lg-1 col-md-6 col-sm-6 col-12">
											<div class="form-group">
											     <label class="label" style="visibility: hidden;"></label>
												<button type="button" class="form-control inbutton" id="addstock" name="addstock" onclick="AddStock()"><span class="icon-add"></span></button>
												</div>
											</div>

											<div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-12">
											<div class="form-group">
												<label class="label">Delivery Time(In Days)</label>
													<input  type="number" tabindex="5" name="deliverytime" id="deliverytime" class="form-control" placeholder="Enter Delivery Time(In Days)" value="<?php if(isset($deliverytime )) echo $deliverytime; ?>" pattern="/^-?\d+\.?\d*$/" onKeyPress="if(this.value.length==3) return false;">
											</div>
										</div>

										<div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-12">
											<div class="form-group">
												<label class="label">Reorder Level</label>
													<input  type="number" tabindex="5" name="reorderlevel" id="reorderlevel" class="form-control" placeholder="Enter Reorder Level" value="<?php if(isset($reorderlevel )) echo $reorderlevel; ?>" pattern="/^-?\d+\.?\d*$/" onKeyPress="if(this.value.length==5) return false;">
											</div>
										</div>

										<div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-12">
											<div class="form-group">
												<label class="label">Minimum Stock</label>
													<input  type="number" tabindex="5" name="minimumstock" id="minimumstock" class="form-control" placeholder="Enter Minimum Stock" value="<?php if(isset($minimumstock )) echo $minimumstock; ?>" pattern="/^-?\d+\.?\d*$/" onKeyPress="if(this.value.length==6) return false;">
											</div>
										</div>

										<div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-12">
											<div class="form-group">
												<label class="label">Maximum Stock</label>
													<input  type="number" tabindex="5" name="maximumstock" id="maximumstock" class="form-control" placeholder="Enter Maximum Stock" value="<?php if(isset($maximumstock )) echo $maximumstock; ?>" pattern="/^-?\d+\.?\d*$/" onKeyPress="if(this.value.length==6) return false;">
											</div>
										</div>

										<div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-12">
										</div>

										<div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-12">
											<div class="custom-control custom-checkbox">
									        <input type="checkbox" value="Yes" <?php if(isset($status)==0){echo'checked';}?> tabindex="25"  class="custom-control-input" id="status" name="status">
										    <label class="custom-control-label" for="status">Status</label>
									        </div>
										</div>

										<div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-12">
										</div>

										<div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-12">
										</div><br /><br /><br /><br />

									<div class="col-md-3">
										<button type="button"  tabindex="17"  id="downloadvendor" name="downloadvendor" class="btn btn-primary"><span class="icon-download"></span>Download</button>
										<button type="button"  tabindex="17"  id="uploadvendor" name="uploadvendor" onclick="Uploadvendor()" class="btn btn-primary"><span class="icon-upload"></span>Upload</button>
									</div>
									<div class="col-md-7">
									</div>
									<div class="col-md-2">
										<button type="submit"  tabindex="17"  id="submitvendorbtn" name="submitvendorbtn" value="Submit" class="btn btn-primary">Submit</button>
										<button type="reset"  tabindex="18"  id="cancelbtn" name="cancelbtn" class="btn btn-outline-secondary">Cancel</button><br /><br />
									</div>


								</div>
							</div>
						</div>

					</div>
				</form>
			</div>