$(document).ready(function () {

// Validate Vendor Name
	$('#vendornamecheck').hide();	
	let vendornameError = true;
	$('#vendorname').keyup(function () {	
	validatevendorname();
	});
	
	function validatevendorname() {
	let vendornameValue = $('#vendorname').val();	
	if (vendornameValue.length == '') {
	$('#vendornamecheck').show();
	vendornameError = false;
		return false;
	}
	else {
		$('#vendornamecheck').hide();
		vendornameError = true;	
	}
	}

// Validate Stocktype
	$('#stocktypecheck').hide();	
	let stocktypeError = true;
	$('#stocktype').keyup(function () {	
	validatestocktype();
	});
	
	function validatestocktype() {
	let stocktypeValue = $('#stocktype').val();	
	if (stocktypeValue.length == '') {
	$('#stocktypecheck').show();
	stocktypeError = false;
		return false;
	}
	else {
		$('#stocktypecheck').hide();
		stocktypeError = true;	
	}
	}

//E-mail check
$('#mailidcheck').hide();	
let mailidError = true;
$('#mailid').keyup(function () {			
	validatmailidid();
});
function validatmailidid() {
var mailid = $('#mailid');
var re = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
if(mailid.val() == ''){
	$('#mailidcheck').hide();
	mailidError = true;
}
else if (!re.test(mailid.val()))
{
	$('#mailidcheck').show();
	mailidError = false;
	return false;
}
else
{
	$('#mailidcheck').hide();
	mailidError = true;
}	
}


//GST check
$('#gstnumbercheck').hide();	
let gstnumberError = true;
$('#gstnumber').keyup(function () {			
	validategstnumber();
});
function validategstnumber() {
var gstnumber = $('#gstnumber');
var reggst = /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/; 
if(gstnumber.val() == ''){
	$('#gstnumbercheck').hide();
	gstnumberError = true;
}
else if (!reggst.test(gstnumber.val()))
{
	$('#gstnumbercheck').show();
	gstnumberError = false;
	return false;
}
else
{
	$('#gstnumbercheck').hide();
	gstnumberError = true;
}	
}

//PAN check
$('#pannumbercheck').hide();	
let pannumberError = true;
$('#pannumber').keyup(function () {			
	validatepannumber();
});
function validatepannumber() {
var pannumber = $('#pannumber');
var regpan = /^([a-zA-Z]){5}([0-9]){4}([a-zA-Z]){1}?$/;
if(pannumber.val() == ''){
	$('#pannumbercheck').hide();
	pannumberError = true;
}
else if (!regpan.test(pannumber.val()))
{
	$('#pannumbercheck').show();
	pannumberError = false;
	return false;
}
else
{
	$('#pannumbercheck').hide();
	pannumberError = true;
}	
}

	$('#downloadvendor').click(function () {
		window.location.href='uploads/downloadfiles/vendorbulksample.xlsx'
	});

	$('#submitvendorbtn').click(function () {
		validatevendorname();
		validatestocktype();
		validatmailidid();
		validatepannumber();
		validategstnumber();

		if (vendornameError == true && stocktypeError == true && mailidError == true && gstnumberError == true && pannumberError == true)
		  {
			return true;
		  } 
		  else 
		  {
			return false;
		  }

	});
});

function Uploadvendor(){
var modal = document.getElementById("VendorBulkUploadModal");
var btn = document.getElementById("uploadvendor");
var span = document.getElementsByClassName("bulkclose")[0];
btn.onclick = function() {
  modal.style.display = "block";
}
span.onclick = function() {
  modal.style.display = "none";
}
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}
}
function AddStock(){
var modal = document.getElementById("AddStockModal");
var btn = document.getElementById("addstock");
var span = document.getElementsByClassName("close")[0];
btn.onclick = function() {
  modal.style.display = "block";
}
span.onclick = function() {
  // DropDownStock();
  modal.style.display = "none";
}
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}
}